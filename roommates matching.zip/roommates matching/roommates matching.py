from openpyxl import *
wb=load_workbook('舍友匹配统计.xlsx')
ws1=wb['男生']
cell1=ws1['B2']
print(cell1.value)
sum=0
for row in ws1.iter_rows(min_col=2,max_col=3,min_row=2,max_row=2):
    print(row)
    for v in row:
        #sum+=float(v.value)
        print(v.value)
#print(sum)
'''import math
num=9.3
xs=num-math.floor(num)

print(xs)'''